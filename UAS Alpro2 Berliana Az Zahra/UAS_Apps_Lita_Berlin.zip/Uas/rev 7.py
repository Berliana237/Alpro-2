import tkinter as tk
from tkinter import ttk, messagebox, filedialog, ttk, Frame
from PIL import Image, ImageTk
import os, shutil, hashlib
import mysql.connector
from datetime import datetime
import csv
import shutil

#Password Admin
def load_admin_credentials(csv_path="admin_users.txt"):
    try:
        with open(csv_path, newline='') as file:
            reader = csv.DictReader(file)
            return list(reader)
    except FileNotFoundError:
        messagebox.showerror("Error", f"File {csv_path} tidak ditemukan.")
        return []

# ---------------- Database ----------------
def connect_db():
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="jualan_makanan_kering"
    )

# Load untuk database
def load_products_from_db():
    try:
        db = connect_db()
        cursor = db.cursor(dictionary=True)
        cursor.execute("SELECT * FROM products")
        return cursor.fetchall()
    except Exception as e:
        messagebox.showerror("Database Error", f"Gagal mengambil produk: {e}")
        return []

UPLOAD_DIR = "bukti_pembayaran"
if not os.path.exists(UPLOAD_DIR):
    os.makedirs(UPLOAD_DIR)

ALLOWED_EXT = [".jpg", ".jpeg", ".png"]

# Warna tema
BG_COLOR = "#f5f0e1"
ACCENT_COLOR = "#f8b400"
BUTTON_COLOR = "#fc8c9e"
TEXT_COLOR = "#333333"
HEADING_COLOR = "#5c3c10"
"""
# Data produk
products = [
    {"name": "Nastar", "price": 15000, "exp_date": "2025-07-01", "image": "images/keripik_singkong.jpg", "stock": 10},
    {"name": "Kastangel", "price": 18000, "exp_date": "2025-06-15", "image": "images/kacang_garlic.jpg", "stock": 8},
    {"name": "Lidah Kucing", "price": 20000, "exp_date": "2025-08-10", "image": "images/emping_balado.jpg", "stock": 5},
    {"name": "Lidah Kucing", "price": 20000, "exp_date": "2025-08-10", "image": "images/emping_balado.jpg", "stock": 5},
    {"name": "Lidah Kucing", "price": 20000, "exp_date": "2025-08-10", "image": "images/emping_balado.jpg", "stock": 5},
    {"name": "Lidah Kucing", "price": 20000, "exp_date": "2025-08-10", "image": "images/emping_balado.jpg", "stock": 5},
    {"name": "Lidah Kucing", "price": 20000, "exp_date": "2025-08-10", "image": "images/emping_balado.jpg", "stock": 5},
    {"name": "Lidah Kucing", "price": 20000, "exp_date": "2025-08-10", "image": "images/emping_balado.jpg", "stock": 5}
]
"""
# ---------------- Login ----------------

class StartWindow(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Toko Kue Kering Nusantara - Login")
        self.geometry("400x280")
        self.configure(bg="#fdf4e3")  # krem lembut

        title_label = tk.Label(self, text="✨ TOKO KUE KERING NUSANTARA ✨", font=("Arial", 16, "bold"),
                               fg="#6b3e26", bg="#fdf4e3")
        title_label.pack(pady=(25, 5))

        subtitle = tk.Label(self, text="Kue Kering Tradisional Berkualitas", font=("Arial", 10, "italic"),
                            fg="#6b3e26", bg="#fdf4e3")
        subtitle.pack(pady=(0, 20))

        btn_customer = tk.Button(self, text="Login Pelanggan", width=25, height=2,
                                 bg="#f49d37", fg="white", font=("Arial", 11, "bold"),
                                 command=self.login_customer)
        btn_customer.pack(pady=8)

        btn_admin = tk.Button(self, text="Login Penjual / Admin", width=25, height=2,
                              bg="#e94e77", fg="white", font=("Arial", 11, "bold"),
                              command=self.login_admin)
        btn_admin.pack(pady=8)

    def login_customer(self):
        self.destroy()
        root = tk.Tk()
        app = CustomerOrderWindowApp(root)
        root.mainloop()

    def login_admin(self):
        AdminLoginWindow(self)

    def open_admin_app(self):
        AdminMainApp(self)

class AdminLoginWindow(tk.Toplevel):
    def __init__(self, master=None):
        super().__init__(master)
        self.title("Login Admin")
        self.geometry("370x250")
        self.configure(bg="#fdf4e3")

        tk.Label(self, text="Login Admin", font=("Arial", 14, "bold"),
                 fg="#6b3e26", bg="#fdf4e3").pack(pady=(20, 10))

        frame_form = tk.Frame(self, bg="#fdf4e3")
        frame_form.pack(pady=5, padx=20)

        tk.Label(frame_form, text="Username:", font=("Arial", 11),
                 bg="#fdf4e3", fg="#6b3e26").grid(row=0, column=0, sticky="w", pady=5)
        self.username_entry = tk.Entry(frame_form, font=("Arial", 11), width=25)
        self.username_entry.grid(row=0, column=1, pady=5)

        tk.Label(frame_form, text="Password:", font=("Arial", 11),
                 bg="#fdf4e3", fg="#6b3e26").grid(row=1, column=0, sticky="w", pady=5)
        self.password_entry = tk.Entry(frame_form, font=("Arial", 11), show="*", width=25)
        self.password_entry.grid(row=1, column=1, pady=5)

        self.show_password_var = tk.IntVar()
        show_password_cb = tk.Checkbutton(self, text="Tampilkan Password",
                                          bg="#fdf4e3", fg="#6b3e26",
                                          variable=self.show_password_var, command=self.toggle_password)
        show_password_cb.pack(pady=5)

        login_btn = tk.Button(self, text="Login", font=("Arial", 11, "bold"),
                              width=20, bg="#f49d37", fg="white", command=self.check_login)
        login_btn.pack(pady=15)

    #sembunyikan atau tampilkan password
    def toggle_password(self):
        self.password_entry.config(show="" if self.show_password_var.get() else "*")

    def check_login(self):
        username = self.username_entry.get()
        password = self.password_entry.get()

        admins = load_admin_credentials()
        for admin in admins:
            if admin['username'] == username and admin['password'] == password:
                messagebox.showinfo("Sukses", "Login berhasil!")
                self.destroy()
                self.master.open_admin_app()
                return

        messagebox.showerror("Error", "Username atau password salah!")

# Customer GUI
class CustomerOrderWindowApp:
    def __init__(self, master):
        self.master = master
        master.title("Aplikasi Jualan Makanan Kering")
        master.geometry("1200x650")
        master.configure(bg="#fdf4e3")
        master.resizable(False, False)

        self.cart = []
        self.products = load_products_from_db()
        self.bg_color = "#fdf4e3"

        self.build_layout()

    def build_layout(self):
        main_frame = tk.Frame(self.master, bg=self.bg_color, width=500)
        main_frame.pack(fill=tk.BOTH, expand=True)

        self.columns = {}
        for idx, kategori in enumerate(["ready", "season"]):  # hanya 2 kolom
            col = tk.Frame(main_frame, bg=self.bg_color, padx=10, pady=10, bd=1, relief="solid")
            col.grid(row=0, column=idx, sticky="nsew")
            self.columns[kategori] = col
            self.build_product_column(col, kategori)

        self.build_cart_column(main_frame)

    def build_product_column(self, parent, kategori):
        emoji = {"ready": "🍪", "season": "🎉"}
        title = {"ready": "Produk Ready Tiap Hari", "season": "Produk Season Hari Spesial"}

        # Judul dengan latar belakang terpisah
        header = tk.Frame(parent, bg="#fcebd3", height=40)
        header.pack(fill=tk.X)
        tk.Label(header, text=f"{emoji[kategori]} {title[kategori]}", font=("Arial", 14, "bold"),
                 fg="#d14c32", bg="#fcebd3", pady=10).pack(anchor="w", padx=10)

        # Scrollable Canvas
        canvas = tk.Canvas(parent, bg=self.bg_color, highlightthickness=0)
        scrollbar = tk.Scrollbar(parent, orient="vertical", command=canvas.yview)
        scroll_frame = tk.Frame(canvas, bg=self.bg_color)

        scroll_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=scroll_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        # Produk per kategori
        filtered = [p for p in self.products if p.get("kategori", "ready") == kategori]

        for product in filtered:
            card = tk.Frame(scroll_frame, bg="white", relief="solid", bd=1, width=370, height=110)
            card.pack_propagate(False)
            card.pack(fill=tk.X, pady=6, padx=8)
            # Gambar produk
            img_path = product.get("image")
            if img_path and os.path.exists(img_path):
                img = Image.open(img_path).resize((80, 80))
            else:
                img = Image.new('RGB', (80, 80), color='gray')
            photo = ImageTk.PhotoImage(img)
            img_label = tk.Label(card, image=photo, bg="white")
            img_label.image = photo
            img_label.pack(side=tk.LEFT, padx=(0, 10), pady=5)
            # Info produk (di samping gambar)
            info = tk.Frame(card, bg="white")
            info.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

            tk.Label(info, text=product['name'], font=("Arial", 11, "bold"),
                     fg="#cc0000", bg="white", anchor="w", justify="left", wraplength=180).pack(anchor="w", pady=(0, 4))
            tk.Label(info, text=f"Rp{product['price']:,}  •  Stok: {product['stock']}",
                     font=("Arial", 10), bg="white", fg="#333", anchor="w").pack(anchor="w")
            tk.Label(info, text=f"Exp: {product['exp_date']}", font=("Arial", 10),
                     bg="white", fg="#777", anchor="w").pack(anchor="w")
            # Tombol tambah ke keranjang
            btn = tk.Button(card, text="🛍", bg="#f25c54", fg="white",
                            font=("Arial", 17, "bold"), command=lambda p=product: self.add_to_cart(p),
                            width=5, anchor="center")
            btn.pack(side=tk.RIGHT, anchor="s", padx=(10, 5), pady=(5, 5))

    def build_cart_column(self, parent):
        cart_frame = tk.Frame(parent, bg="#fdebd0", padx=10, pady=10, bd=1, relief="solid")
        cart_frame.grid(row=0, column=3, sticky="nsew")

        tk.Label(cart_frame, text="🛍 Keranjang Belanja", font=("Arial", 14, "bold"),
                 bg="#fdebd0", fg="#cc4c00").pack(pady=(0, 10))

        self.cart_listbox = tk.Listbox(cart_frame, font=("Arial", 11), width=35, height=20, justify="left")
        self.cart_listbox.pack()
        
        self.total_price_label = tk.Label(cart_frame, text="Total: Rp0", font=("Arial", 12, "bold"),
                                  bg="#fdebd0", fg="#333")
        self.total_price_label.pack(pady=(5, 10))

        btn_frame = tk.Frame(cart_frame, bg="#fdebd0")
        btn_frame.pack(pady=10)

        tk.Button(btn_frame, text="❌ Hapus dari Keranjang", bg="#e74c3c", fg="white",
                  font=("Arial", 10), command=self.remove_from_cart).pack(fill=tk.X, pady=5)

        tk.Button(btn_frame, text="✅ Checkout", bg="green", fg="white",
                  font=("Arial", 10), command=self.checkout).pack(fill=tk.X, pady=5)

        tk.Button(btn_frame, text="⬅️ Kembali ke Login", bg="#999", fg="white",
                  font=("Arial", 10), command=self.go_back_to_login).pack(fill=tk.X, pady=5)

    def add_to_cart(self, product):
        if product['stock'] > 0:
            self.cart.append(product)
            self.cart_listbox.insert(tk.END, f"{product['name']} - Rp{product['price']:,}")
            product['stock'] -= 1
            self.update_total_price()
            self.refresh_all_product_columns()
            messagebox.showinfo("Berhasil", f"{product['name']} telah ditambahkan ke keranjang.")
        else:
            messagebox.showwarning("Stok Habis", f"Stok {product['name']} habis.")
    
    def update_total_price(self):
        total = sum(item['price'] for item in self.cart)
        self.total_price_label.config(text=f"Total: Rp{total:,}")

    def remove_from_cart(self):
        selection = self.cart_listbox.curselection()
        if selection:
            index = selection[0]
            product = self.cart[index]
            # Kembalikan stok produk
            for p in self.products:
                if p['id'] == product['id']:
                    p['stock'] += 1
                    break
            self.cart_listbox.delete(index)
            self.cart.pop(index)
            self.update_total_price()
            self.refresh_all_product_columns()
                
    def refresh_all_product_columns(self):
        # Perbarui ulang tampilan produk di kedua kolom
        for kategori in ["ready", "season"]:
            for widget in self.columns[kategori].winfo_children():
                widget.destroy()
            self.build_product_column(self.columns[kategori], kategori)

    def checkout(self):
        if not self.cart:
            messagebox.showwarning("Kosong", "Keranjang masih kosong.")
            return

        self.bukti_pembayaran_path = None

        form_window = tk.Toplevel(self.master)
        form_window.title("Form Checkout")
        form_window.geometry("400x480")
        form_window.configure(bg="#fdfdfd")
        form_window.resizable(False, False)

        tk.Label(form_window, text="Formulir Pelanggan", font=("Arial", 14, "bold"), bg="#fdfdfd").pack(pady=10)

        form_frame = tk.Frame(form_window, bg="#fdfdfd")
        form_frame.pack(pady=5, padx=20, fill=tk.X)

        tk.Label(form_frame, text="Nama:", bg="#fdfdfd").grid(row=0, column=0, sticky="w", pady=5)
        name_entry = tk.Entry(form_frame, width=30)
        name_entry.grid(row=0, column=1, pady=5)

        tk.Label(form_frame, text="No. Telepon:", bg="#fdfdfd").grid(row=1, column=0, sticky="w", pady=5)
        phone_entry = tk.Entry(form_frame, width=30)
        phone_entry.grid(row=1, column=1, pady=5)

        tk.Label(form_frame, text="Alamat:", bg="#fdfdfd").grid(row=2, column=0, sticky="nw", pady=5)
        address_entry = tk.Text(form_frame, width=23, height=3)
        address_entry.grid(row=2, column=1, pady=5)

        tk.Label(form_frame, text="Tanggal Ambil:", bg="#fdfdfd").grid(row=3, column=0, sticky="w", pady=5)
        date_entry = tk.Entry(form_frame, width=30)
        date_entry.grid(row=3, column=1, pady=5)
        date_entry.insert(0, datetime.now().strftime("%Y-%m-%d"))
        
        tk.Label(form_frame, text="Silakan transfer ke rekening BCA berikut:", bg="#fdfdfd", fg="#333").grid(row=4, column=0, columnspan=2, sticky="w", pady=(10, 0))
        tk.Label(form_frame, text="BCA 1234567890 a.n. TOKO KUE KERING NUSANTARA", bg="#fdfdfd", fg="#cc0000").grid(row=5, column=0, columnspan=2, sticky="w")

        tk.Label(form_frame, text="Bukti Pembayaran:", bg="#fdfdfd").grid(row=6, column=0, sticky="w", pady=5)
        file_label = tk.Label(form_frame, text="Belum ada file", bg="#fdfdfd", anchor="w")
        file_label.grid(row=6, column=1, sticky="w", pady=5)

        def pilih_file():
            path = filedialog.askopenfilename(filetypes=[("Gambar", "*.jpg *.png *.jpeg")])
            if path:
                self.bukti_pembayaran_path = path
                file_label.config(text=os.path.basename(path))

        tk.Button(form_frame, text="Pilih File", command=pilih_file, bg="#dcdcdc").grid(row=7, column=1, sticky="w")

        def submit_order():
            name = name_entry.get().strip()
            phone = phone_entry.get().strip()
            address = address_entry.get("1.0", tk.END).strip()
            pickup_date = date_entry.get().strip()

            if not name or not phone or not address or not pickup_date:
                messagebox.showwarning("Peringatan", "Mohon lengkapi semua data.")
                return

            if not self.bukti_pembayaran_path:
                messagebox.showwarning("Peringatan", "Silakan upload bukti pembayaran terlebih dahulu.")
                return

            ext = os.path.splitext(self.bukti_pembayaran_path)[1].lower()
            if ext not in ALLOWED_EXT:
                messagebox.showerror("Error", "Format file tidak didukung. Hanya jpg, jpeg, png.")
                return

            try:
                # Simpan file ke folder lokal
                new_filename = f"{name}_{datetime.now().strftime('%Y%m%d%H%M%S')}{ext}"
                saved_path = os.path.join(UPLOAD_DIR, new_filename)
                shutil.copy(self.bukti_pembayaran_path, saved_path)

                total = sum(item['price'] for item in self.cart)

                db = connect_db()
                cursor = db.cursor()
                cursor.execute("INSERT INTO orders (nama, no_telp, alamat, pickup_date, total, bukti_pembayaran) VALUES (%s, %s, %s, %s, %s, %s)",
                               (name, phone, address, pickup_date, total, saved_path))
                order_id = cursor.lastrowid

                rekap = {}
                for item in self.cart:
                    key = (item['name'], item['id'])
                    if key not in rekap:
                        rekap[key] = 0
                    rekap[key] += 1

                for (nama_produk, id_produk), jumlah in rekap.items():
                    cursor.execute("""
                        INSERT INTO rekap_pesanan (order_id, nama_produk, id_produk, jumlah_dibeli, nama_pemesan)
                        VALUES (%s, %s, %s, %s, %s)
                    """, (order_id, nama_produk, id_produk, jumlah, name))
                # Kurangi stok di database sesuai jumlah beli
                for (nama_produk, id_produk), jumlah in rekap.items():
                    cursor.execute("UPDATE products SET stock = stock - %s WHERE id = %s", (jumlah, id_produk))

                db.commit()
                db.close()

                self.cart.clear()
                self.products = load_products_from_db()  # Ambil ulang produk dari database
                self.refresh_all_product_columns()
                self.cart_listbox.delete(0, tk.END)
                self.update_total_price()
                self.refresh_all_product_columns()
                messagebox.showinfo("Berhasil", "Pesanan berhasil disimpan!")
                form_window.destroy()
            except Exception as e:
                messagebox.showerror("Error", str(e))

        tk.Button(form_window, text="Submit Pesanan", command=submit_order, bg="#4caf50", fg="white", font=("Arial", 11, "bold")).pack(pady=20)

    def go_back_to_login(self):
        self.master.destroy()  # Tutup jendela customer

        # Buka kembali jendela login
        app = StartWindow()
        app.mainloop()

#Admin GUI
class AdminMainApp(tk.Toplevel):
    def __init__(self, master=None):
        super().__init__(master)
        self.title("Admin Dashboard")
        self.geometry("1200x700")
        self.configure(bg="#f0f0f0")
        self.resizable(False, False)
        
        self.user = {'username': 'admin', 'role': 'admin'}
        
        # Header
        header = tk.Frame(self, bg="#4a4e69", height=60)
        header.pack(fill=tk.X)
        tk.Label(header, text="Admin Dashboard - Toko Kue Kering", bg="#4a4e69", fg="white",
        font=("Helvetica", 16, "bold")).pack(pady=15)
        
        # Notebook Tabs
        self.tabs = ttk.Notebook(self)
        self.tabs.pack(expand=1, fill="both")
        
        # Buat frame untuk tiap tab
        self.tab_produk = tk.Frame(self.tabs, bg="#f5f0e1")
        self.tab_supplier = tk.Frame(self.tabs, bg="#f5f0e1")
        self.tab_pesanan = tk.Frame(self.tabs, bg="#f5f0e1")
        
        # Tambahkan tab
        self.tabs.add(self.tab_produk, text="Manajemen Produk")
        self.tabs.add(self.tab_supplier, text="Manajemen Supplier")
        self.tabs.add(self.tab_pesanan, text="Pesanan")
        
        # Inisialisasi fitur dari MainApp
        self.build_products_tab()
        self.build_suppliers_tab()
        self.build_orders_tab()
    
    #tab Manajemen Product
    def build_products_tab(self):
        left_frame = tk.Frame(self.tab_produk, bg="#f5f0e1", width=400)
        left_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=10, pady=10)

        right_frame = tk.Frame(self.tab_produk, bg="#f5f0e1")
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=10, pady=10)

        # Daftar Produk (Listbox seperti di menu pelanggan)
        tk.Label(left_frame, text="Daftar Produk", font=("Arial", 16, "bold"), bg="#f5f0e1").pack(pady=(0, 10))

        list_frame = tk.Frame(left_frame, bg="#f5f0e1")
        list_frame.pack(fill=tk.BOTH, expand=True)

        scrollbar = tk.Scrollbar(list_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        self.product_listbox_admin = tk.Listbox(list_frame, width=40, height=20, font=("Arial", 11),
                                                selectbackground="#f8b400", activestyle="none",
                                                bd=1, relief="solid", highlightthickness=0)
        self.product_listbox_admin.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        self.product_listbox_admin.config(yscrollcommand=scrollbar.set)
        scrollbar.config(command=self.product_listbox_admin.yview)

        self.load_admin_product_list()
        self.product_listbox_admin.bind('<<ListboxSelect>>', self.fill_product_form)

        # Formulir Produk
        tk.Label(right_frame, text="Formulir Produk", font=("Arial", 16, "bold"), bg="#f5f0e1").pack(pady=(0, 10))

        labels = ["Nama Produk", "Harga", "Stok", "Tanggal Exp (YYYY-MM-DD)", "Supplier ID"]
        self.entry_fields_admin = {}

        for label in labels:
            frame = tk.Frame(right_frame, bg="#f5f0e1")
            frame.pack(fill=tk.X, pady=5)
            tk.Label(frame, text=label + ":", width=20, anchor="w", bg="#f5f0e1").pack(side=tk.LEFT)
            entry = tk.Entry(frame, width=30)
            entry.pack(side=tk.LEFT)
            self.entry_fields_admin[label] = entry

        self.selected_image_path = None
        self.label_gambar_admin = tk.Label(right_frame, text="Belum ada file", bg="#f5f0e1")
        self.label_gambar_admin.pack(pady=5)

        def pilih_gambar():
            file_path = filedialog.askopenfilename(filetypes=[("Image files", "*.jpg *.png")])
            if file_path:
                self.selected_image_path = file_path
                self.label_gambar_admin.config(text=os.path.basename(file_path))

        tk.Button(right_frame, text="Pilih Gambar", command=pilih_gambar, bg="#d3d3d3").pack(pady=5)

        tk.Button(right_frame, text="Tambah Produk", command=self.admin_tambah_produk, bg="green", fg="white").pack(pady=5, fill=tk.X)
        tk.Button(right_frame, text="Edit Produk", command=self.admin_edit_produk, bg="orange", fg="white").pack(pady=5, fill=tk.X)
        tk.Button(right_frame, text="Hapus Produk", command=self.admin_hapus_produk, bg="red", fg="white").pack(pady=5, fill=tk.X)

    def load_admin_product_list(self):
        self.product_listbox_admin.delete(0, tk.END)
        try:
            db = connect_db()
            cursor = db.cursor(dictionary=True)
            cursor.execute("SELECT * FROM products")
            self.products_admin = cursor.fetchall()
            for product in self.products_admin:
                self.product_listbox_admin.insert(tk.END, f"{product['name']} - Rp{product['price']:,} (Stok: {product['stock']})")
            db.close()
        except Exception as e:
            messagebox.showerror("Error", f"Gagal memuat produk: {e}")

    def fill_product_form(self, event):
        selection = self.product_listbox_admin.curselection()
        if selection:
            index = selection[0]
            product = self.products_admin[index]
            self.entry_fields_admin["Nama Produk"].delete(0, tk.END)
            self.entry_fields_admin["Nama Produk"].insert(0, product['name'])
            self.entry_fields_admin["Harga"].delete(0, tk.END)
            self.entry_fields_admin["Harga"].insert(0, product['price'])
            self.entry_fields_admin["Stok"].delete(0, tk.END)
            self.entry_fields_admin["Stok"].insert(0, product['stock'])
            self.entry_fields_admin["Tanggal Exp (YYYY-MM-DD)"].delete(0, tk.END)
            self.entry_fields_admin["Tanggal Exp (YYYY-MM-DD)"].insert(0, product['exp_date'])
            self.entry_fields_admin["Supplier ID"].delete(0, tk.END)
            supplier_id = product.get('supplier_id')
            if supplier_id is not None:
                self.entry_fields_admin["Supplier ID"].insert(0, str(supplier_id))
            else:
                self.entry_fields_admin["Supplier ID"].delete(0, tk.END)
                
            self.editing_product_id = product['id']

    def admin_tambah_produk(self):
        data = {k: v.get().strip() for k, v in self.entry_fields_admin.items()}
        required_fields = ["Nama Produk", "Harga", "Stok", "Tanggal Exp (YYYY-MM-DD)"]
        if not all(data[f] for f in required_fields):
            messagebox.showwarning("Peringatan", "Mohon lengkapi semua data (kecuali Supplier ID boleh kosong).")
            return

        try:
            supplier_id = int(data["Supplier ID"]) if data["Supplier ID"] else None

            db = connect_db()
            cursor = db.cursor()

            cursor.execute(
                "INSERT INTO products (name, price, stock, exp_date, supplier_id) VALUES (%s, %s, %s, %s, %s)",
                (data["Nama Produk"], int(data["Harga"]), int(data["Stok"]),
                 data["Tanggal Exp (YYYY-MM-DD)"], supplier_id)
            )

            db.commit()
            db.close()
            self.load_admin_product_list()
            messagebox.showinfo("Sukses", "Produk berhasil ditambahkan.")
        except ValueError:
            messagebox.showerror("Error", "Harga, Stok, dan Supplier ID harus berupa angka.")
        except Exception as e:
            messagebox.showerror("Error", f"Gagal menambahkan produk: {e}")

    def admin_edit_produk(self):
        if not hasattr(self, 'editing_product_id'):
            messagebox.showwarning("Pilih Produk", "Pilih produk yang akan diedit.")
            return

        data = {k: v.get().strip() for k, v in self.entry_fields_admin.items()}

        required_fields = ["Nama Produk", "Harga", "Stok", "Tanggal Exp (YYYY-MM-DD)"]
        if not all(data[f] for f in required_fields):
            messagebox.showwarning("Peringatan", "Mohon lengkapi semua data (kecuali Supplier ID boleh kosong).")
            return

        try:
            harga = int(data["Harga"])
            stok = int(data["Stok"])
            supplier_id = int(data["Supplier ID"]) if data["Supplier ID"] else None  # Bisa None

            db = connect_db()
            cursor = db.cursor()
            cursor.execute(
                "UPDATE products SET name=%s, price=%s, stock=%s, exp_date=%s, supplier_id=%s WHERE id=%s",
                (data["Nama Produk"], harga, stok, data["Tanggal Exp (YYYY-MM-DD)"], supplier_id, self.editing_product_id)
            )

            db.commit()
            db.close()
            self.load_admin_product_list()
            messagebox.showinfo("Sukses", "Produk berhasil diperbarui.")
        except ValueError:
            messagebox.showerror("Error", "Harga, Stok, dan Supplier ID harus berupa angka.")
        except Exception as e:
            messagebox.showerror("Error", f"Gagal mengedit produk: {e}")

    def admin_hapus_produk(self):
        selection = self.product_listbox_admin.curselection()
        if not selection:
            messagebox.showwarning("Pilih Produk", "Pilih produk yang ingin dihapus.")
            return
        index = selection[0]
        product = self.products_admin[index]
        if messagebox.askyesno("Konfirmasi", f"Hapus produk '{product['name']}'?"):
            try:
                db = connect_db()
                cursor = db.cursor()
                cursor.execute("DELETE FROM products WHERE id = %s", (product['id'],))
                db.commit()
                db.close()
                self.load_admin_product_list()
                messagebox.showinfo("Sukses", "Produk berhasil dihapus.")
            except Exception as e:
                messagebox.showerror("Error", f"Gagal menghapus produk: {e}")
            
#tab MAnajemen Supplier
    def build_suppliers_tab(self):
        tk.Label(self.tab_supplier, text="Daftar Supplier", font=("Arial", 16, "bold"),
                 bg="#f5f0e1").pack(pady=10)

        self.tree_supplier = ttk.Treeview(self.tab_supplier, columns=("ID", "Nama", "No Telepon", "Alamat", "Bahan"), show="headings")
        self.tree_supplier.heading("ID", text="ID")
        self.tree_supplier.heading("Nama", text="Nama")
        self.tree_supplier.heading("No Telepon", text="No Telepon")
        self.tree_supplier.heading("Alamat", text="Alamat")
        self.tree_supplier.heading("Bahan", text="Bahan")
        self.tree_supplier.pack(fill=tk.BOTH, padx=20, pady=10, expand=True)

        def load_suppliers():
            self.tree_supplier.delete(*self.tree_supplier.get_children())
            try:
                db = connect_db()
                cursor = db.cursor()
                cursor.execute("SELECT id, nama, no_telp, alamat, bahan FROM suppliers")
                for row in cursor.fetchall():
                    self.tree_supplier.insert('', tk.END, values=row)
                db.close()
            except Exception as e:
                messagebox.showerror("Error", f"Gagal memuat supplier: {e}")

        def tambah_supplier():
            form = tk.Toplevel(self.master)
            form.title("Tambah Supplier")
            form.geometry("400x350")
            form.configure(bg="#fff")

            labels = ["ID", "Nama", "No Telepon", "Alamat", "Bahan"]
            entries = []

            for i, label in enumerate(labels):
                tk.Label(form, text=label, bg="#fff").grid(row=i, column=0, padx=10, pady=5, sticky="w")
                if label == "Alamat":
                    ent = tk.Text(form, width=30, height=3)
                else:
                    ent = tk.Entry(form, width=30)
                ent.grid(row=i, column=1, pady=5)
                entries.append(ent)

            def simpan():
                try:
                    id_supplier = int(entries[0].get().strip())
                    nama = entries[1].get().strip()
                    no_telp = entries[2].get().strip()
                    alamat = entries[3].get("1.0", tk.END).strip()
                    bahan = entries[4].get().strip()

                    if not id_supplier or not nama or not no_telp or not alamat or not bahan:
                        messagebox.showwarning("Peringatan", "Mohon lengkapi semua data.")
                        return

                    db = connect_db()
                    cursor = db.cursor()
                    cursor.execute(
                        "INSERT INTO suppliers (id, nama, no_telp, alamat, bahan) VALUES (%s, %s, %s, %s, %s)",
                        (id_supplier, nama, no_telp, alamat, bahan)
                    )
                    db.commit()
                    db.close()
                    load_suppliers()
                    form.destroy()
                except ValueError:
                    messagebox.showerror("Error", "ID harus berupa angka.")
                except Exception as e:
                    messagebox.showerror("Error", f"Gagal menambah supplier: {e}")

            tk.Button(form, text="Simpan", command=simpan, bg="#4caf50", fg="white").grid(row=6, columnspan=2, pady=20)

        def hapus_supplier():
            selected = self.tree_supplier.selection()
            if not selected:
                messagebox.showwarning("Pilih", "Pilih supplier yang ingin dihapus.")
                return
            id_supplier = self.tree_supplier.item(selected[0])['values'][0]
            if messagebox.askyesno("Konfirmasi", f"Hapus supplier ID '{id_supplier}'?"):
                try:
                    db = connect_db()
                    cursor = db.cursor()
                    cursor.execute("DELETE FROM suppliers WHERE id = %s", (id_supplier,))
                    db.commit()
                    db.close()
                    load_suppliers()
                except Exception as e:
                    messagebox.showerror("Error", f"Gagal menghapus supplier: {e}")

        # Tombol
        tk.Button(self.tab_supplier, text="Tambah Supplier", command=tambah_supplier,
                  bg="#4caf50", fg="white").pack(pady=5)

        tk.Button(self.tab_supplier, text="Hapus Supplier", command=hapus_supplier,
                  bg="#f44336", fg="white").pack(pady=5)

        load_suppliers()

#tab Order Pelanggan
    def build_orders_tab(self):
        tk.Label(self.tab_pesanan, text="Daftar Pesanan", font=("Arial", 16, "bold"),
                 bg="#f5f0e1").pack(pady=10)
        
        #form pencarian tanggal
        filter_frame = tk.Frame(self.tab_pesanan, bg="#f5f0e1")
        filter_frame.pack(pady=5)

        tk.Label(filter_frame, text="Cari berdasarkan Tanggal Ambil (YYYY-MM-DD):", bg="#f5f0e1").pack(side=tk.LEFT)
        self.filter_date_entry = tk.Entry(filter_frame, width=15)
        self.filter_date_entry.pack(side=tk.LEFT, padx=5)

        tk.Button(filter_frame, text="Filter", command=self.filter_orders_by_date, bg="#f8b400").pack(side=tk.LEFT)
        tk.Button(filter_frame, text="Tampilkan Semua", command=self.load_orders, bg="#ccc").pack(side=tk.LEFT, padx=5)

        self.tree_orders = ttk.Treeview(self.tab_pesanan, columns=("Nama", "Telepon", "Tanggal", "Pesanan", "Status"), show="headings")
        self.tree_orders.heading("Nama", text="Nama")
        self.tree_orders.heading("Telepon", text="Telepon")
        self.tree_orders.heading("Tanggal", text="Tanggal Ambil")
        self.tree_orders.heading("Pesanan", text="Pesanan")
        self.tree_orders.heading("Status", text="Status")
        self.tree_orders.pack(fill=tk.BOTH, padx=20, pady=10, expand=True)
            
        def tandai_sudah_dikirim():
            selected = self.tree_orders.selection()
            if not selected:
                messagebox.showwarning("Pilih Pesanan", "Pilih pesanan yang ingin diperbarui.")
                return

            index = self.tree_orders.index(selected[0])
            order_id = self.orders_data[index][0]  # Ambil ID dari hasil query

            try:
                db = connect_db()
                cursor = db.cursor()
                cursor.execute("UPDATE orders SET status='selesai' WHERE id=%s", (order_id,))
                db.commit()
                db.close()
                self.load_orders()
                messagebox.showinfo("Sukses", "Status pesanan diperbarui menjadi 'selesai'.")
            except Exception as e:
                messagebox.showerror("Error", f"Gagal memperbarui status: {e}")

        tk.Button(self.tab_pesanan, text="Tandai Sudah Dikirim", command=tandai_sudah_dikirim, bg="#4caf50", fg="white").pack(pady=5)

        self.load_orders()

    def load_orders(self):
        self.tree_orders.delete(*self.tree_orders.get_children())
        try:
            db = connect_db()
            cursor = db.cursor()
            cursor.execute("""
                SELECT 
                    o.id,
                    o.nama, 
                    o.no_telp, 
                    o.pickup_date,
                    COALESCE(GROUP_CONCAT(CONCAT(r.nama_produk, ' x', r.jumlah_dibeli) SEPARATOR ', '), '-') AS pesanan,
                    o.status
                FROM orders o
                LEFT JOIN rekap_pesanan r ON o.id = r.order_id
                GROUP BY o.id
                ORDER BY 
                    CASE WHEN o.status = 'pending' THEN 0 ELSE 1 END,
                    o.pickup_date ASC
            """)
            self.orders_data = cursor.fetchall()
            for row in self.orders_data:
                self.tree_orders.insert('', tk.END, values=row[1:])
            db.close()
        except Exception as e:
            messagebox.showerror("Error", f"Gagal memuat pesanan: {e}")

    def filter_orders_by_date(self):
        tanggal = self.filter_date_entry.get().strip()
        if not tanggal:
            messagebox.showwarning("Input Kosong", "Masukkan tanggal terlebih dahulu.")
            return
        try:
            db = connect_db()
            cursor = db.cursor()
            cursor.execute("""
                SELECT 
                    o.id,
                    o.nama, 
                    o.no_telp, 
                    o.pickup_date,
                    COALESCE(GROUP_CONCAT(CONCAT(r.nama_produk, ' x', r.jumlah_dibeli) SEPARATOR ', '), '-') AS pesanan,
                    o.status
                FROM orders o
                LEFT JOIN rekap_pesanan r ON o.id = r.order_id
                WHERE o.pickup_date = %s
                GROUP BY o.id
                ORDER BY 
                    CASE WHEN o.status = 'pending' THEN 0 ELSE 1 END,
                    o.pickup_date ASC
            """, (tanggal,))
            results = cursor.fetchall()
            db.close()

            self.tree_orders.delete(*self.tree_orders.get_children())
            for row in results:
                self.tree_orders.insert('', tk.END, values=row[1:])
        except Exception as e:
            messagebox.showerror("Error", f"Gagal memfilter pesanan: {e}")

if __name__ == "__main__":
    app = StartWindow()
    app.mainloop()

