-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versi server:                 10.4.32-MariaDB - mariadb.org binary distribution
-- OS Server:                    Win64
-- HeidiSQL Versi:               12.10.0.7000
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Membuang struktur basisdata untuk jualan_makanan_kering
CREATE DATABASE IF NOT EXISTS `jualan_makanan_kering` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;
USE `jualan_makanan_kering`;

-- membuang struktur untuk table jualan_makanan_kering.orders
CREATE TABLE IF NOT EXISTS `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) NOT NULL,
  `no_telp` varchar(20) NOT NULL,
  `alamat` text DEFAULT NULL,
  `pickup_date` date NOT NULL,
  `total` int(11) DEFAULT NULL,
  `detail_pesanan` text NOT NULL,
  `bukti_pembayaran` varchar(255) NOT NULL,
  `status` enum('pending','selesai') DEFAULT 'pending',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Membuang data untuk tabel jualan_makanan_kering.orders: ~17 rows (lebih kurang)
INSERT INTO `orders` (`id`, `nama`, `no_telp`, `alamat`, `pickup_date`, `total`, `detail_pesanan`, `bukti_pembayaran`, `status`) VALUES
	(10, 'elang', '345678909', 'jl.kalijudan', '2025-05-29', 18000, '', 'default.jpg', 'selesai'),
	(11, 'Melvyn', '54267167', 'jl.kalijud', '2025-05-30', 15000, '', 'C:/Users/berli/OneDrive/Hình ảnh/Screenshots/Cuplikan layar 2025-05-21 100656.png', 'pending'),
	(12, 'daniel', '1234454', 'jl.kalijudan', '2025-05-30', 15000, '', 'C:/Users/berli/OneDrive/Hình ảnh/Screenshots/Cuplikan layar 2025-05-03 201954.png', 'selesai'),
	(13, 'alexa', '4536270', 'jl.kalijudan', '2025-05-29', 15000, '', 'bukti_pembayaran\\alexa_20250521113729.png', 'pending'),
	(14, 'gabe', '534162', 'jl.kalijudan', '2025-05-29', 15000, '', 'bukti_pembayaran\\gabe_20250522140839.jpg', 'pending'),
	(15, 'elang', '57632109', 'jl.kalijudan', '2025-05-30', 15000, '', 'bukti_pembayaran\\elang_20250522141303.png', 'pending'),
	(16, 'kev', '2341231', 'jl.biduro', '2025-05-29', 40000, '', 'bukti_pembayaran\\kev_20250522141626.png', 'pending'),
	(17, 'fsa', '`2354', 'jl.madura', '2025-06-12', 15000, '', 'bukti_pembayaran\\fsa_20250522142042.png', 'selesai'),
	(18, 'hgf', '23456', 'jl.yhb', '2025-05-30', 20000, '', 'bukti_pembayaran\\hgf_20250522142230.png', 'pending'),
	(19, 'jhgcv', '132456', 'jl.hari', '2025-05-29', 25000, '', 'bukti_pembayaran\\jhgcv_20250522142336.jpg', 'selesai'),
	(20, 'hy', '132422', 'jl.jai', '2025-05-29', 18000, '', 'bukti_pembayaran\\hy_20250522142652.jpg', 'pending'),
	(21, 'haks', '1213432556645', 'jl.kali', '2025-05-29', 25000, '', 'bukti_pembayaran\\haks_20250522142750.png', 'pending'),
	(22, 'har', '324532', 'jl.jar', '2025-06-21', 15000, '', 'bukti_pembayaran\\har_20250522142926.jpg', 'selesai'),
	(23, 'berlin', '083572412', 'Jl.Biduri', '2025-06-10', 20000, '', 'bukti_pembayaran\\berlin_20250525221432.jpg', 'pending'),
	(24, 'erlang', '09752648152', 'Jl.Dinoyo', '2025-06-20', 18000, '', 'bukti_pembayaran\\erlang_20250525224219.png', 'pending'),
	(25, 'caren', '0828671478', 'Jl.Kalijaran', '2025-06-20', 195000, '', 'bukti_pembayaran\\caren_20250526121903.png', 'pending'),
	(26, 'Kevin', '0872851648', 'Jl.Kalijaran', '2025-06-12', 120000, '', 'bukti_pembayaran\\Kevin_20250527074327.jpg', 'pending');

-- membuang struktur untuk table jualan_makanan_kering.products
CREATE TABLE IF NOT EXISTS `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `stock` int(11) DEFAULT NULL,
  `exp_date` date DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `kategori` enum('ready','season','hampers') DEFAULT 'ready',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Membuang data untuk tabel jualan_makanan_kering.products: ~12 rows (lebih kurang)
INSERT INTO `products` (`id`, `name`, `price`, `stock`, `exp_date`, `image`, `supplier_id`, `kategori`) VALUES
	(1, 'Kue Jahe', 15000, 10, '2025-07-01', 'kue jahe.jpg', 1, 'season'),
	(2, 'Kastangel', 18000, 7, '2025-06-15', 'kastangel.jpg', NULL, 'ready'),
	(3, 'Semprit Keju', 20000, 20, '2025-08-10', 'semprit.jpg', NULL, 'ready'),
	(6, 'Kacang', 20000, 10, '2025-08-10', 'kue kacang.jpeg', NULL, 'ready'),
	(7, 'Lidah Kucing', 20000, 5, '2025-08-10', 'lidah kucing.jpg', NULL, 'ready'),
	(8, 'semprit Sprinkle ', 20000, 5, '2025-08-10', 'springkel.jpg', NULL, 'ready'),
	(9, 'Kue Kering Lebaran Mini Pack', 25000, 29, '2025-07-01', 'hampers mini.jpg', NULL, 'season'),
	(10, 'Hampers Chineese New Year', 32000, 20, '2025-06-20', 'hampers chineese.jpeg', NULL, 'season'),
	(11, 'Kue Nastar Special Idul Fitri', 28000, 25, '2025-07-10', 'nastar.jpg', NULL, 'season'),
	(12, 'Hampers Lebaran Premium', 150000, 9, '2025-07-10', 'hampers premium.jpg', NULL, 'season'),
	(14, 'Hampers Natal', 120000, 7, '2025-07-05', 'hampers natal.jpg', NULL, 'season'),
	(15, 'Coklat Stick', 20000, 37, '2025-08-20', 'thumprint.jpeg', NULL, 'ready');

-- membuang struktur untuk table jualan_makanan_kering.rekap_pesanan
CREATE TABLE IF NOT EXISTS `rekap_pesanan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) DEFAULT NULL,
  `nama_produk` varchar(100) DEFAULT NULL,
  `id_produk` int(11) DEFAULT NULL,
  `jumlah_dibeli` int(11) DEFAULT NULL,
  `nama_pemesan` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`),
  CONSTRAINT `rekap_pesanan_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Membuang data untuk tabel jualan_makanan_kering.rekap_pesanan: ~20 rows (lebih kurang)
INSERT INTO `rekap_pesanan` (`id`, `order_id`, `nama_produk`, `id_produk`, `jumlah_dibeli`, `nama_pemesan`) VALUES
	(1, 10, 'Kastangel', 2, 1, 'elang'),
	(2, 11, 'Nastar', 1, 1, 'Melvyn'),
	(3, 12, 'Nastar', 1, 1, 'daniel'),
	(4, 13, 'Nastar', 1, 1, 'alexa'),
	(5, 14, 'Kue Jahe', 1, 1, 'gabe'),
	(6, 15, 'Kue Jahe', 1, 1, 'elang'),
	(7, 16, 'Kue Jahe', 1, 1, 'kev'),
	(8, 16, 'Kue Kering Lebaran Mini Pack', 9, 1, 'kev'),
	(9, 17, 'Kue Jahe', 1, 1, 'fsa'),
	(10, 18, 'Semprit Keju', 3, 1, 'hgf'),
	(11, 19, 'Kue Kering Lebaran Mini Pack', 9, 1, 'jhgcv'),
	(12, 20, 'Kastangel', 2, 1, 'hy'),
	(13, 21, 'Kue Kering Lebaran Mini Pack', 9, 1, 'haks'),
	(14, 22, 'Kue Jahe', 1, 1, 'har'),
	(15, 23, 'Semprit Keju', 3, 1, 'berlin'),
	(16, 24, 'Kastangel', 2, 1, 'erlang'),
	(17, 25, 'Kacang', 6, 1, 'caren'),
	(18, 25, 'Kue Kering Lebaran Mini Pack', 9, 1, 'caren'),
	(19, 25, 'Hampers Lebaran Premium', 12, 1, 'caren'),
	(20, 26, 'Hampers Natal', 14, 1, 'Kevin');

-- membuang struktur untuk table jualan_makanan_kering.suppliers
CREATE TABLE IF NOT EXISTS `suppliers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) NOT NULL,
  `no_telp` varchar(20) NOT NULL,
  `alamat` text NOT NULL,
  `bahan` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Membuang data untuk tabel jualan_makanan_kering.suppliers: ~7 rows (lebih kurang)
INSERT INTO `suppliers` (`id`, `nama`, `no_telp`, `alamat`, `bahan`) VALUES
	(1, 'Supratman', '0862815472', 'jl.Pandan raya', 'Mentega, Butter'),
	(2, 'Budi', '09756234735', 'Jl.Biduri Bulan', 'Telur'),
	(3, 'Tono Supratno', '0827638267', 'Jl.Phirus Biru', 'Tepung, Gula Halus'),
	(4, 'Budi Santoso', '08928731672', 'Jl.Biduri Bulan', 'Pewarna, Selai'),
	(5, 'Supriyanto', '081837802', 'Jl.Mutiara', 'Gula Pasir, Kacang'),
	(6, 'Budiyanto', '0891232638', 'Jl.Granit Kumala', 'Minyak'),
	(7, 'Nardi', '0853267818', 'Jl.Kalijaran', 'Toples');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
