CREATE TABLE orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama VARCHAR(100),
    no_telp VARCHAR(20),
    alamat TEXT,
    pickup_date DATE,
    total INT,
    detail_pesanan TEXT,
    bukti_pembayaran VARCHAR(255),
    status ENUM('pending', 'selesai') DEFAULT 'pending'
);

CREATE TABLE products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    price INT,
    stock INT,
    exp_date DATE,
    image VARCHAR(255),
    supplier_id INT
);

CREATE TABLE IF NOT EXISTS cancelled_orders (
                id INT PRIMARY KEY AUTO_INCREMENT,
                order_id INT NOT NULL,
                cancel_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                total DECIMAL(10,2) NOT NULL,
                status VARCHAR(30) DEFAULsuppliersT 'Dibatalkan',
                discount INT,
                FOREIGN KEY (order_id) REFERENCES orders(id)
            )
            
            
CREATE TABLE IF NOT EXISTS suppliers (
                id INT PRIMARY KEY AUTO_INCREMENT,
                nama VARCHAR(100) NOT NULL,
                no_telp VARCHAR(20) NOT NULL,
                alamat TEXT NOT NULL,
                bahan VARCHAR(100) NOT NULL
            )
            
CREATE TABLE order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT DEFAULT 1,
    FOREIGN KEY (order_id) REFERENCES orders(id),
    FOREIGN KEY (product_id) REFERENCES products(id)
);

CREATE TABLE rekap_pesanan (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT,
    nama_produk VARCHAR(100),
    id_produk INT,
    jumlah_dibeli INT,
    nama_pemesan VARCHAR(100),
    FOREIGN KEY (order_id) REFERENCES orders(id)
);

SELECT 
    p.name AS nama_produk,
    p.id AS id_produk,
    oi.quantity AS jumlah_dibeli,
    o.nama AS nama_pemesan
FROM order_items oi
JOIN products p ON oi.product_id = p.id
JOIN orders o ON oi.order_id = o.id
ORDER BY o.nama;

INSERT INTO products (name, price, stock, exp_date, image, supplier_id) VALUES
('Nastar', 15000, 10, '2025-07-01', 'images/keripik_singkong.jpg', NULL),
('Kastangel', 18000, 8, '2025-06-15', 'images/kacang_garlic.jpg', NULL),
('Lidah Kucing', 20000, 5, '2025-08-10', 'images/emping_balado.jpg', NULL),
('Lidah Kucing', 20000, 5, '2025-08-10', 'images/emping_balado.jpg', NULL),
('Lidah Kucing', 20000, 5, '2025-08-10', 'images/emping_balado.jpg', NULL),
('Lidah Kucing', 20000, 5, '2025-08-10', 'images/emping_balado.jpg', NULL),
('Lidah Kucing', 20000, 5, '2025-08-10', 'images/emping_balado.jpg', NULL),
('Lidah Kucing', 20000, 5, '2025-08-10', 'images/emping_balado.jpg', NULL);


SELECT * FROM orders WHERE bukti_pembayaran IS NULL OR bukti_pembayaran = '';

UPDATE orders
SET bukti_pembayaran = 'default.jpg'
WHERE bukti_pembayaran IS NULL OR bukti_pembayaran = '';


ALTER TABLE orders
MODIFY bukti_pembayaran VARCHAR(255) NOT NULL;

ALTER TABLE products ADD COLUMN kategori ENUM('ready', 'season', 'hampers') DEFAULT 'ready';

INSERT INTO products (name, price, stock, exp_date, image, kategori)
VALUES
('Kue Kering Lebaran Mini Pack', 25000, 30, '2025-07-01', 'images/season1.jpg', 'season'),
('Parsel Kue Coklat', 32000, 20, '2025-06-20', 'images/season2.jpg', 'season'),
('Kue Nastar Special Idul Fitri', 28000, 25, '2025-07-10', 'images/season3.jpg', 'season');

INSERT INTO products (name, price, stock, exp_date, image, kategori)
VALUES
('Hampers Lebaran Premium', 150000, 10, '2025-07-10', 'images/hampers1.jpg', 'hampers'),
('Hampers Mini Isi 3 Toples', 90000, 12, '2025-06-30', 'images/hampers2.jpg', 'hampers'),
('Hampers Signature Box', 120000, 8, '2025-07-05', 'images/hampers3.jpg', 'hampers');


